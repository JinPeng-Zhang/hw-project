# FatTree 项目

## 描述
这是一个使用 NS-3 (版本 3.45) 模拟 k=4 FatTree 拓扑的项目，支持 ECN、ECMP 和 PFC。
- 拓扑：16 主机，8 边交换机，8 聚合交换机，4 核心交换机。
- 功能：ECN (RedQueueDisc)，ECMP (全局路由多路径)，PFC (优先级流控制)。

## 构建和运行
在 fattree/ 目录下运行：
#清理→编译→运行→：
rm -rf build
cmake -S . -B build
cmake --build build -j4


./build/fattree   --ecmpMode=perflow   --pfc=1 --pfcHighPkts=5 --pfcLowPkts=3   --pfcPktSize=1472   --simTime=15

./build/fattree --ecmpMode=perflow --pfc=1 --simTime=3

./build/fattree --ecmpMode=perflow --pfc=1 --pfcHighPkts=1 --pfcLowPkts=0 --pfcFanIn=16 --pfcRate=1000000000 --pfcPktSize=1448 --ecn=0 --simTime=6


ecmpMode:perflow(基于流的 ECMP)/perpacket(基于包的 ECMP)
pfc=0(禁用)/1(启用)
pfcHighPkts(拥塞触发高水位)
pfcLowPkts(拥塞恢复低水位)
pfcFanIn=16(Incast 场景的发送方数量)
pfcRate=1000000000(每个 sender 的发送速率bps)
pfcPktSize=1448(应用层包大小byte)
ecn=0(禁用)/1(启用)
simTime=6(仿真时长（秒）)




