#include "experiments.h"
#include "model/fattree-topology.h"

#include <ns3/core-module.h>
#include <ns3/internet-module.h>
#include <ns3/flow-monitor-module.h>
#include <ns3/ipv4-global-routing-helper.h>
#include <ns3/output-stream-wrapper.h>

#include <ns3/node-list.h>
#include <ns3/ipv4.h>
#include <ns3/ipv4-list-routing.h>
#include <ns3/ipv4-global-routing.h>

#include "pfc/qbb-net-device.h"
#include "traffic/test.h"

using namespace ns3;

namespace fattree {

// 配置 ECMP（perflow/perpacket）
static void ApplyEcmpConfig(const std::string& mode) {
  const bool perflow   = (mode != "perpacket");
  const bool perpacket = !perflow;

  Config::SetDefault("ns3::Ipv4GlobalRouting::PerflowEcmpRouting", BooleanValue(perflow));
  Config::SetDefault("ns3::Ipv4GlobalRouting::RandomEcmpRouting",  BooleanValue(perpacket));

  const std::string base = "/NodeList/*/$ns3::Ipv4L3Protocol/$ns3::Ipv4ListRouting/$ns3::Ipv4GlobalRouting/";
  Config::Set(base + "PerflowEcmpRouting", BooleanValue(perflow));
  Config::Set(base + "RandomEcmpRouting",  BooleanValue(perpacket));
}

// 强制对已创建实例生效
static void ForceEcmpConfigRuntime(const std::string& mode) {
  const bool perflow   = (mode != "perpacket");
  const bool perpacket = !perflow;

  for (uint32_t i = 0; i < NodeList::GetNNodes(); ++i) {
    Ptr<Node> n = NodeList::GetNode(i);
    Ptr<Ipv4> ipv4 = n->GetObject<Ipv4>();
    if (!ipv4) continue;

    Ptr<Ipv4ListRouting> list = DynamicCast<Ipv4ListRouting>(ipv4->GetRoutingProtocol());
    if (!list) continue;

    for (uint32_t k = 0; k < list->GetNRoutingProtocols(); ++k) {
      int16_t prio = 0;
      Ptr<Ipv4RoutingProtocol> rp = list->GetRoutingProtocol(k, prio);
      Ptr<Ipv4GlobalRouting> gr = DynamicCast<Ipv4GlobalRouting>(rp);
      if (!gr) continue;

      gr->SetAttribute("PerflowEcmpRouting", BooleanValue(perflow));
      gr->SetAttribute("RandomEcmpRouting",  BooleanValue(perpacket));
    }
  }
}

// 下发 PFC 属性
static void ApplyPfcConfig(bool enable, uint32_t highPkts, uint32_t lowPkts, uint16_t defaultQuanta = 65535) {
  Config::Set("/NodeList/*/DeviceList/*/$ns3::QbbNetDevice/PfcEnable",      BooleanValue(enable));
  Config::Set("/NodeList/*/DeviceList/*/$ns3::QbbNetDevice/PfcHighPkts",    UintegerValue(highPkts));
  Config::Set("/NodeList/*/DeviceList/*/$ns3::QbbNetDevice/PfcLowPkts",     UintegerValue(lowPkts));
  Config::Set("/NodeList/*/DeviceList/*/$ns3::QbbNetDevice/DefaultQuanta",  UintegerValue(defaultQuanta));
}

void RunScenario(FatTreeTopology& topo,
                 double simTime,
                 const std::string& ecmpMode,
                 bool pfcOn,
                 uint32_t pfcHighPkts,
                 uint32_t pfcLowPkts,
                 uint32_t pfcFanIn,
                 double pfcRateBps,
                 uint32_t pfcPktSize)
{
  // ECMP
  ApplyEcmpConfig(ecmpMode);
  ForceEcmpConfigRuntime(ecmpMode);

  // PFC
  ApplyPfcConfig(pfcOn, pfcHighPkts, pfcLowPkts);

  // 安装测试流量（traffic/test.cc）
  traffic::InstallPfcTestTraffic(topo, simTime, pfcFanIn, pfcRateBps, pfcPktSize, 9000);

  // 路由表输出（可选）
  {
    Ipv4GlobalRoutingHelper gr;
    Ptr<OutputStreamWrapper> out = Create<OutputStreamWrapper>("routes.txt", std::ios::out);
    gr.PrintRoutingTableAllAt(Seconds(0.2), out);
  }

  // 运行与统计（FlowMonitor）
  FlowMonitorHelper fm; Ptr<FlowMonitor> mon = fm.InstallAll();
  Simulator::Stop(Seconds(simTime));
  Simulator::Run();

  mon->CheckForLostPackets();
  Ptr<Ipv4FlowClassifier> cls = DynamicCast<Ipv4FlowClassifier>(fm.GetClassifier());
  for (const auto& kv : mon->GetFlowStats()) {
    const auto& st = kv.second;
    auto t = cls->FindFlow(kv.first);
    double dur = (st.timeLastRxPacket - st.timeFirstTxPacket).GetSeconds();
    double thr = dur>0 ? (st.rxBytes*8.0/dur/1024.0/1024.0) : 0.0;
    NS_LOG_INFO("Flow " << t.sourceAddress << ":" << t.sourcePort
                 << " -> " << t.destinationAddress << ":" << t.destinationPort
                 << " tx=" << st.txPackets << " rx=" << st.rxPackets
                 << " lost=" << st.lostPackets << " thr=" << thr << " Mbps");
  }
  Simulator::Destroy();
}

} // namespace fattree
