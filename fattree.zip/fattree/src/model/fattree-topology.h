#ifndef FATTREE_TOPOLOGY_H
#define FATTREE_TOPOLOGY_H

#include <cstdint>

#include <ns3/node-container.h>
#include <ns3/internet-stack-helper.h>
#include <ns3/ipv4-address-helper.h>

namespace ns3 {

// 简化版 FatTree 拓扑（仅使用 QbbPointToPointHelper 进行 PFC 配置；无 ECN/RED）
class FatTreeTopology
{
public:
  explicit FatTreeTopology(uint32_t k);

  NodeContainer GetHosts() const;
  NodeContainer GetEdgeSwitches() const;
  NodeContainer GetAggSwitches() const;
  NodeContainer GetCoreSwitches() const;

private:
  void BuildTopology();
  void InstallInternetStack();
  void AssignIpAddresses();
  void InstallMobility();

private:
  uint32_t m_k;

  // 拓扑节点
  NodeContainer m_coreSwitches;
  NodeContainer m_aggSwitches;
  NodeContainer m_edgeSwitches;
  NodeContainer m_hosts;

  // 基础助手：分配 IP、安装协议栈
  Ipv4AddressHelper   m_ipHelper;
  InternetStackHelper m_stack;
};

} // namespace ns3

#endif // FATTREE_TOPOLOGY_H
