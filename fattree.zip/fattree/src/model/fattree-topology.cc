#include "fattree-topology.h"

#include <ns3/string.h>
#include <ns3/boolean.h>
#include <ns3/double.h>
#include <ns3/uinteger.h>
#include <ns3/config.h>
#include <ns3/log.h>
#include <ns3/node-list.h>
#include <ns3/point-to-point-net-device.h>
#include <ns3/mobility-helper.h>
#include <ns3/constant-position-mobility-model.h>
#include <ns3/vector.h>
#include <ns3/ipv4-global-routing-helper.h>

// 真实 PFC（基于 p2p）
#include "pfc/qbb-point-to-point-helper.h"
#include "pfc/qbb-net-device.h"

namespace ns3 {

FatTreeTopology::FatTreeTopology(uint32_t k) : m_k(k) {
  // 每条链路独立 /24 子网，从 10.0.0.0 起
  m_ipHelper.SetBase("10.0.0.0", "255.255.255.0");

  BuildTopology();           // 1) 连接（QbbPointToPointHelper，启用真实 PFC）
  InstallInternetStack();    // 2) 协议栈
  AssignIpAddresses();       // 3) 分配IP（每链路一子网）
  InstallMobility();         // 4) 固定位置（供 NetAnim）
    
  // 立即填充路由表
  Ipv4GlobalRoutingHelper::PopulateRoutingTables();
  // 无 ECN/RED 安装；PFC 由 QbbNetDevice 属性直接生效
}

void FatTreeTopology::BuildTopology() {
  uint32_t numPods = m_k;
  uint32_t numCore = m_k * m_k / 4;
  uint32_t numAggPerPod = m_k / 2;
  uint32_t numEdgePerPod = m_k / 2;
  uint32_t numHostsPerEdge = m_k / 2;

  // 使用真实 PFC 的 p2p helper
  QbbPointToPointHelper qbb;
  // 链路速率/时延（按需修改）
  qbb.SetDeviceAttribute("DataRate", StringValue("1Mbps"));
  qbb.SetChannelAttribute("Delay", StringValue("1ms"));

  // PFC 配置（按需修改，或在 main 中用 Config::SetDefault 覆盖 QbbNetDevice 属性）
  qbb.SetPfcAttribute("PfcEnable", BooleanValue(true));
  // 例：高/低阈值（单位=包），默认 8/4；你可改为 12/6 等
  // qbb.SetPfcAttribute("PfcHighPkts", UintegerValue(8));
  // qbb.SetPfcAttribute("PfcLowPkts",  UintegerValue(4));
  // 默认暂停量 quanta（512 bit-times），收到 XON 会立即解除
  // qbb.SetPfcAttribute("DefaultQuanta", UintegerValue(65535));

  // 创建节点
  m_coreSwitches.Create(numCore);
  m_aggSwitches.Create(numPods * numAggPerPod);
  m_edgeSwitches.Create(numPods * numEdgePerPod);
  m_hosts.Create(numPods * numEdgePerPod * numHostsPerEdge);

  // edge <-> host
  for (uint32_t pod = 0; pod < numPods; ++pod) {
    for (uint32_t edge = 0; edge < numEdgePerPod; ++edge) {
      uint32_t edgeIdx = pod * numEdgePerPod + edge;
      for (uint32_t host = 0; host < numHostsPerEdge; ++host) {
        uint32_t hostIdx = edgeIdx * numHostsPerEdge + host;
        qbb.Install(m_edgeSwitches.Get(edgeIdx), m_hosts.Get(hostIdx));
      }
    }
  }

  // agg <-> edge
  for (uint32_t pod = 0; pod < numPods; ++pod) {
    for (uint32_t agg = 0; agg < numAggPerPod; ++agg) {
      uint32_t aggIdx = pod * numAggPerPod + agg;
      for (uint32_t edge = 0; edge < numEdgePerPod; ++edge) {
        uint32_t edgeIdx = pod * numEdgePerPod + edge;
        qbb.Install(m_aggSwitches.Get(aggIdx), m_edgeSwitches.Get(edgeIdx));
      }
    }
  }

  // core <-> agg (ECMP 多路径)
  for (uint32_t coreGroup = 0; coreGroup < m_k / 2; ++coreGroup) {
    for (uint32_t core = 0; core < m_k / 2; ++core) {
      uint32_t coreIdx = coreGroup * (m_k / 2) + core;
      for (uint32_t pod = 0; pod < numPods; ++pod) {
        uint32_t aggIdx = pod * (m_k / 2) + coreGroup;
        qbb.Install(m_coreSwitches.Get(coreIdx), m_aggSwitches.Get(aggIdx));
      }
    }
  }
}

void FatTreeTopology::InstallInternetStack() {
  // 为所有节点打开 IP 转发
  m_stack.SetIpv4StackInstall(true);
  
  m_stack.Install(m_hosts);
  m_stack.Install(m_edgeSwitches);
  m_stack.Install(m_aggSwitches);
  m_stack.Install(m_coreSwitches);
  
  // 显式设置所有节点的转发属性
  for (uint32_t i = 0; i < NodeList::GetNNodes(); ++i) {
    Ptr<Node> node = NodeList::GetNode(i);
    Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
    if (ipv4) {
      ipv4->SetAttribute("IpForward", BooleanValue(true));
    }
  }
}


void FatTreeTopology::AssignIpAddresses() {
  // k=4 索引布局：
  // Edge: 下联 host [0..1]，上联 agg [2..3]
  // Agg : 下联 edge [0..1]，上联 core [2..3]
  // Core: 下联 pod  [0..3]
  uint32_t numPods = m_k;
  uint32_t numEdgePerPod = m_k / 2;     // 2
  uint32_t numHostsPerEdge = m_k / 2;   // 2
  uint32_t numAggPerPod = m_k / 2;      // 2

  // edge <-> host
  for (uint32_t pod = 0; pod < numPods; ++pod) {
    for (uint32_t edge = 0; edge < numEdgePerPod; ++edge) {
      uint32_t edgeIdx = pod * numEdgePerPod + edge;
      for (uint32_t host = 0; host < numHostsPerEdge; ++host) {
        uint32_t hostIdx = edgeIdx * numHostsPerEdge + host;
        NetDeviceContainer devices;
        devices.Add(m_edgeSwitches.Get(edgeIdx)->GetDevice(host));
        devices.Add(m_hosts.Get(hostIdx)->GetDevice(0));
        m_ipHelper.Assign(devices);
        m_ipHelper.NewNetwork(); // 每链路 /24
      }
    }
  }

  // agg <-> edge
  for (uint32_t pod = 0; pod < numPods; ++pod) {
    for (uint32_t agg = 0; agg < numAggPerPod; ++agg) {
      uint32_t aggIdx = pod * numAggPerPod + agg;
      for (uint32_t edge = 0; edge < numEdgePerPod; ++edge) {
        uint32_t edgeIdx = pod * numEdgePerPod + edge;
        uint32_t edgeDevIdx = numHostsPerEdge + agg; // 2 + agg
        uint32_t aggDevIdx  = edge;                  // 0 or 1
        NetDeviceContainer devices;
        devices.Add(m_aggSwitches.Get(aggIdx)->GetDevice(aggDevIdx));
        devices.Add(m_edgeSwitches.Get(edgeIdx)->GetDevice(edgeDevIdx));
        m_ipHelper.Assign(devices);
        m_ipHelper.NewNetwork();
      }
    }
  }

  // core <-> agg
  for (uint32_t coreGroup = 0; coreGroup < m_k / 2; ++coreGroup) {
    for (uint32_t core = 0; core < m_k / 2; ++core) {
      uint32_t coreIdx = coreGroup * (m_k / 2) + core;
      for (uint32_t pod = 0; pod < numPods; ++pod) {
        uint32_t aggIdx = pod * numAggPerPod + coreGroup;
        uint32_t aggDevIdx  = numEdgePerPod + core; // 2 + core
        uint32_t coreDevIdx = pod;                  // 0..3
        NetDeviceContainer devices;
        devices.Add(m_coreSwitches.Get(coreIdx)->GetDevice(coreDevIdx));
        devices.Add(m_aggSwitches.Get(aggIdx)->GetDevice(aggDevIdx));
        m_ipHelper.Assign(devices);
        m_ipHelper.NewNetwork();
      }
    }
  }
}

void FatTreeTopology::InstallMobility() {
  // 为所有节点安装 ConstantPositionMobilityModel 并布局在四层
  MobilityHelper mobility;
  mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  NodeContainer all;
  all.Add(m_hosts);
  all.Add(m_edgeSwitches);
  all.Add(m_aggSwitches);
  all.Add(m_coreSwitches);
  mobility.Install(all);

  // 简单的二维布局：每个 pod 占 200 的宽度
  const double podWidth = 200.0;
  const double yHost = 0.0;
  const double yEdge = 40.0;
  const double yAgg  = 80.0;
  const double yCore = 120.0;

  uint32_t numPods = m_k;
  uint32_t numEdgePerPod = m_k / 2;
  uint32_t numHostsPerEdge = m_k / 2;
  uint32_t numAggPerPod = m_k / 2;

  // edge/host
  for (uint32_t pod = 0; pod < numPods; ++pod) {
    double baseX = pod * podWidth;
    for (uint32_t e = 0; e < numEdgePerPod; ++e) {
      uint32_t edgeIdx = pod * numEdgePerPod + e;
      double edgeX = baseX + 50.0 + e * 100.0;
      {
        Ptr<MobilityModel> mm = m_edgeSwitches.Get(edgeIdx)->GetObject<MobilityModel>();
        mm->SetPosition(Vector(edgeX, yEdge, 0.0));
      }
      for (uint32_t h = 0; h < numHostsPerEdge; ++h) {
        uint32_t hostIdx = edgeIdx * numHostsPerEdge + h;
        double hostX = edgeX + (h == 0 ? -25.0 : 25.0);
        Ptr<MobilityModel> mm = m_hosts.Get(hostIdx)->GetObject<MobilityModel>();
        mm->SetPosition(Vector(hostX, yHost, 0.0));
      }
    }
  }

  // agg
  for (uint32_t pod = 0; pod < numPods; ++pod) {
    double baseX = pod * podWidth;
    for (uint32_t a = 0; a < numAggPerPod; ++a) {
      uint32_t aggIdx = pod * numAggPerPod + a;
      double aggX = baseX + 50.0 + a * 100.0;
      Ptr<MobilityModel> mm = m_aggSwitches.Get(aggIdx)->GetObject<MobilityModel>();
      mm->SetPosition(Vector(aggX, yAgg, 0.0));
    }
  }

  // core
  for (uint32_t i = 0; i < m_coreSwitches.GetN(); ++i) {
    double x = 50.0 + i * 100.0 + podWidth; // 稍微居中
    Ptr<MobilityModel> mm = m_coreSwitches.Get(i)->GetObject<MobilityModel>();
    mm->SetPosition(Vector(x, yCore, 0.0));
  }
}

NodeContainer FatTreeTopology::GetHosts() const { return m_hosts; }
NodeContainer FatTreeTopology::GetEdgeSwitches() const { return m_edgeSwitches; }
NodeContainer FatTreeTopology::GetAggSwitches() const { return m_aggSwitches; }
NodeContainer FatTreeTopology::GetCoreSwitches() const { return m_coreSwitches; }

} // namespace ns3
