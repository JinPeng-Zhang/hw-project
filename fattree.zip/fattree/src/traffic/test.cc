#include "traffic/test.h"
#include "model/fattree-topology.h"

#include <ns3/core-module.h>
#include <ns3/internet-module.h>
#include <ns3/applications-module.h>
#include <ns3/ipv4-global-routing-helper.h>
#include <ns3/udp-socket-factory.h>
#include <ns3/ipv4-l3-protocol.h>
#include <ns3/node-list.h>
#include <ns3/ipv4-header.h>
#include <ns3/data-rate.h>
#include <ns3/uinteger.h>

#include "qbb-net-device.h"

#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>
#include <limits>
#include <sstream>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("TrafficTest");

namespace traffic {

static const uint8_t kWatchPrio = 3;

struct LinkToMonitor {
  uint32_t aggrNodeId;
  uint32_t aggrDevId;       // Aggr 侧与 Edge 相连的设备索引（修正为设备下标）
  uint32_t edgeNodeId;
  uint32_t edgeDevId;       // Edge 侧与 Aggr 相连的设备索引
  uint32_t high;
  uint32_t low;
  uint32_t edgeHostPortId;  // Edge->Host 的设备索引
  uint32_t sinkNodeId;      // 接收主机节点 id
};

static LinkToMonitor g_monitorLink;

static Ipv4Address GetFirstNonLoopbackIp(Ptr<Node> node)
{
  Ptr<Ipv4> ipv4 = node->GetObject<Ipv4>();
  for (uint32_t i = 1; ipv4 && i < ipv4->GetNInterfaces(); ++i)
  {
    if (ipv4->GetNAddresses(i) > 0)
    {
      return ipv4->GetAddress(i, 0).GetLocal();
    }
  }
  return Ipv4Address("0.0.0.0");
}

// 发送固定数量的包
static void SendFixedPackets(Ptr<Socket> s, uint32_t payloadBytes, Time interval,
                             uint32_t totalPackets, uint32_t sentCount)
{
  if (sentCount >= totalPackets) {
    std::cout << std::fixed << std::setprecision(6) << Simulator::Now().GetSeconds()
              << "s [SENDER] Finished sending " << totalPackets << " packets" << std::endl;
    return;
  }
  s->Send(Create<Packet>(payloadBytes));
  Simulator::Schedule(interval, &SendFixedPackets, s, payloadBytes, interval,
                      totalPackets, sentCount + 1);
}

// 链路“上线”节奏：在接收端口的 MacRx 打印（反映发送端真实上线节奏+信道时延）
static void TraceOnWireAggrToEdgeRx(Ptr<const Packet> p)
{
  static Time lastRx = Seconds(0);
  Time now = Simulator::Now();
  double intervalUs = lastRx.IsZero() ? 0.0 : (now - lastRx).GetMicroSeconds();

  std::cout << std::fixed << std::setprecision(6) << now.GetSeconds()
            << "s [ONWIRE Aggr->Edge RX]"
            << " size=" << p->GetSize()
            << " interval=" << std::setprecision(2) << intervalUs << "us"
            << std::endl;

  lastRx = now;
}

// 周期性监控链路状态
static void MonitorLinkStatus()
{
  static uint32_t lastRxQ = 0;
  static bool lastAggrPaused = false;
  static uint64_t lastEdgeTxXoff = 0;
  static uint64_t lastEdgeTxXon = 0;
  static uint64_t lastAggrRxXoff = 0;
  static uint64_t lastAggrRxXon = 0;
  static bool firstRun = true;

  Time now = Simulator::Now();

  Ptr<Node> edgeNode = NodeList::GetNode(g_monitorLink.edgeNodeId);
  Ptr<QbbNetDevice> edgeDev = DynamicCast<QbbNetDevice>(edgeNode->GetDevice(g_monitorLink.edgeDevId));

  Ptr<Node> aggrNode = NodeList::GetNode(g_monitorLink.aggrNodeId);
  Ptr<QbbNetDevice> aggrDev = DynamicCast<QbbNetDevice>(aggrNode->GetDevice(g_monitorLink.aggrDevId));

  if (!edgeDev || !aggrDev) {
    Simulator::Schedule(MilliSeconds(2), &MonitorLinkStatus);
    return;
  }

  uint32_t rxQ = edgeDev->GetRxOccupancy(kWatchPrio);
  bool aggrPaused = aggrDev->IsPaused(kWatchPrio);
  uint64_t edgeTxXoff = edgeDev->GetTxXoffCount(kWatchPrio);
  uint64_t edgeTxXon = edgeDev->GetTxXonCount(kWatchPrio);
  uint64_t aggrRxXoff = aggrDev->GetRxXoffCount(kWatchPrio);
  uint64_t aggrRxXon = aggrDev->GetRxXonCount(kWatchPrio);

  if (firstRun) {
    std::cout << "\n=== Monitor Started at " << std::fixed << std::setprecision(6)
              << now.GetSeconds() << "s ===\n" << std::endl;
    firstRun = false;
    lastRxQ = rxQ;
    lastAggrPaused = aggrPaused;
    lastEdgeTxXoff = edgeTxXoff;
    lastEdgeTxXon = edgeTxXon;
    lastAggrRxXoff = aggrRxXoff;
    lastAggrRxXon = aggrRxXon;
  }

  bool hasEvent = false;
  std::ostringstream oss;
  oss << std::fixed << std::setprecision(6) << now.GetSeconds() << "s ";

  if (rxQ != lastRxQ) {
    if (lastRxQ < g_monitorLink.high && rxQ >= g_monitorLink.high) {
      oss << "[EDGE-RXQ] " << lastRxQ << "->" << rxQ
          << " (>= HIGH=" << g_monitorLink.high << ")";
      hasEvent = true;
    } else if (lastRxQ > g_monitorLink.low && rxQ <= g_monitorLink.low) {
      oss << "[EDGE-RXQ] " << lastRxQ << "->" << rxQ
          << " (<= LOW=" << g_monitorLink.low << ")";
      hasEvent = true;
    } else if (std::abs((int)rxQ - (int)lastRxQ) >= 3) {
      oss << "[EDGE-RXQ] " << lastRxQ << "->" << rxQ;
      hasEvent = true;
    }
  }

  if (edgeTxXoff != lastEdgeTxXoff) {
    if (hasEvent) oss << " | ";
    oss << "[EDGE->XOFF]";
    hasEvent = true;
  }

  if (edgeTxXon != lastEdgeTxXon) {
    if (hasEvent) oss << " | ";
    oss << "[EDGE->XON]";
    hasEvent = true;
  }

  if (aggrPaused != lastAggrPaused) {
    if (hasEvent) oss << " | ";
    if (aggrPaused) {
      oss << "[AGGR-PAUSED]";
    } else {
      oss << "[AGGR-RESUME]";
    }
    hasEvent = true;
  }

  if (hasEvent) {
    std::cout << oss.str() << std::endl;
  }

  static Time lastReport = Seconds(0);
  if (now - lastReport >= MilliSeconds(50)) {
    std::cout << std::fixed << std::setprecision(6) << now.GetSeconds()
              << "s [STATUS] Edge.rxQ=" << std::setw(2) << rxQ
              << " | Aggr." << (aggrPaused ? "PAUSED" : "ACTIVE")
              << " | XOFF=" << edgeTxXoff << " XON=" << edgeTxXon
              << std::endl;
    lastReport = now;
  }

  lastRxQ = rxQ;
  lastAggrPaused = aggrPaused;
  lastEdgeTxXoff = edgeTxXoff;
  lastEdgeTxXon = edgeTxXon;
  lastAggrRxXoff = aggrRxXoff;
  lastAggrRxXon = aggrRxXon;

  Simulator::Schedule(MilliSeconds(2), &MonitorLinkStatus);
}

// 打印 Edge 节点上“Edge->Host 出端口”的令牌注册参数（rate/avgPkt/pps/burst）
static void PrintEdgeTokenRegistration()
{
  using std::cout; using std::endl;
  Time now = Simulator::Now();

  if (g_monitorLink.edgeNodeId >= NodeList::GetNNodes()) {
    Simulator::Schedule(MilliSeconds(10), &PrintEdgeTokenRegistration);
    return;
  }

  Ptr<Node> edgeNode = NodeList::GetNode(g_monitorLink.edgeNodeId);
  if (!edgeNode) {
    Simulator::Schedule(MilliSeconds(10), &PrintEdgeTokenRegistration);
    return;
  }

  if (g_monitorLink.edgeHostPortId >= edgeNode->GetNDevices() ||
      g_monitorLink.edgeDevId >= edgeNode->GetNDevices())
  {
    cout << std::fixed << std::setprecision(6) << now.GetSeconds()
         << "s [TOKEN-REG] Edge devices not ready, retry..." << endl;
    Simulator::Schedule(MilliSeconds(10), &PrintEdgeTokenRegistration);
    return;
  }

  Ptr<QbbNetDevice> hostDev    = DynamicCast<QbbNetDevice>(edgeNode->GetDevice(g_monitorLink.edgeHostPortId)); // Edge->Host
  Ptr<QbbNetDevice> ingressDev = DynamicCast<QbbNetDevice>(edgeNode->GetDevice(g_monitorLink.edgeDevId));      // Edge<-Aggr

  if (!hostDev || !ingressDev) {
    cout << std::fixed << std::setprecision(6) << now.GetSeconds()
         << "s [TOKEN-REG] QbbNetDevice not ready, retry..." << endl;
    Simulator::Schedule(MilliSeconds(10), &PrintEdgeTokenRegistration);
    return;
  }

  DataRateValue rateHost, rateIngress;
  UintegerValue avgHost, avgIngress;

  hostDev->GetAttribute("DataRate", rateHost);
  ingressDev->GetAttribute("DataRate", rateIngress);
  hostDev->GetAttribute("AvgPktSize", avgHost);
  ingressDev->GetAttribute("AvgPktSize", avgIngress);

  const double brHost = rateHost.Get().GetBitRate();
  const double brIngress = rateIngress.Get().GetBitRate();
  const uint32_t avgHostBytes = avgHost.Get();
  const uint32_t avgIngressBytes = avgIngress.Get();

  const double ppsReg = (avgIngressBytes > 0) ? (brHost / (avgIngressBytes * 8.0)) : 0.0;
  const uint32_t burstReg = std::max(8u, static_cast<uint32_t>(ppsReg * 0.001));

  cout << std::fixed << std::setprecision(6) << now.GetSeconds()
       << "s [TOKEN-REG] Edge node=" << g_monitorLink.edgeNodeId << endl;

  cout << "  Edge->Host dev=" << g_monitorLink.edgeHostPortId
       << " rate=" << static_cast<uint64_t>(brHost) << "bps"
       << " avgPkt(used)=" << avgIngressBytes
       << " => pps=" << std::setprecision(2) << ppsReg
       << " burst=" << burstReg << endl;

  cout << "  Edge<-Aggr dev=" << g_monitorLink.edgeDevId
       << " rate=" << static_cast<uint64_t>(brIngress) << "bps"
       << " avgPkt(dev)=" << avgIngressBytes
       << " avgPkt(hostPort)=" << avgHostBytes << endl;

  Ptr<EgressTokenManager> mgr = edgeNode->GetObject<EgressTokenManager>();
  cout << "  EgressTokenManager: " << (mgr ? "present" : "absent") << endl;
}

void InstallPfcTestTraffic(FatTreeTopology& topo,
                           double simTime,
                           uint32_t /*fanIn*/,
                           double /*rateBps*/,
                           uint32_t pktSize,
                           uint16_t basePort)
{
  auto hosts = topo.GetHosts();
  NS_ABORT_MSG_IF(hosts.GetN() == 0, "No hosts");

  const uint32_t Nh = hosts.GetN();
  const uint32_t k = static_cast<uint32_t>(std::lround(std::cbrt(4.0 * Nh)));
  const uint32_t numEdgePerPod = k / 2;
  const uint32_t numHostsPerEdge = k / 2;
  const uint32_t hostsPerPod = numEdgePerPod * numHostsPerEdge;

  const uint32_t sinkPod = k - 1;
  const uint32_t sinkFirstIdx = sinkPod * hostsPerPod;
  Ptr<Node> sink = hosts.Get(sinkFirstIdx);
  Ipv4Address sinkIp = GetFirstNonLoopbackIp(sink);

  std::cout << "\n=== PFC Link Monitor (Aggr->Edge) ===" << std::endl;

  auto edges = topo.GetEdgeSwitches();
  auto aggrs = topo.GetAggSwitches();

  Ptr<Node> sinkEdge = nullptr;
  uint32_t edgeToAggrPort = 0;
  Ptr<Node> connectedAggr = nullptr;
  uint32_t aggrToEdgePort = 0;
  uint32_t edgeToHostPort = std::numeric_limits<uint32_t>::max();

  // 找到：与接收主机相连的 Edge 及其 Host 端口；同时找到该 Edge 上连向某 Aggr 的端口
  for (uint32_t i = 0; i < edges.GetN(); ++i) {
    Ptr<Node> edge = edges.Get(i);
    for (uint32_t d = 0; d < edge->GetNDevices(); ++d) {
      Ptr<QbbNetDevice> dev = DynamicCast<QbbNetDevice>(edge->GetDevice(d));
      if (!dev) continue;

      Ptr<Channel> ch = dev->GetChannel();
      if (!ch || ch->GetNDevices() < 2) continue;

      Ptr<NetDevice> peer = (ch->GetDevice(0) == dev) ? ch->GetDevice(1) : ch->GetDevice(0);
      if (peer && peer->GetNode() == sink) {
        sinkEdge = edge;
        edgeToHostPort = d; // Edge->Host 端口

        // 在这个 Edge 上找一个上联到 Aggr 的端口
        for (uint32_t dd = 0; dd < edge->GetNDevices(); ++dd) {
          Ptr<QbbNetDevice> upDev = DynamicCast<QbbNetDevice>(edge->GetDevice(dd));
          if (!upDev) continue;
          Ptr<Channel> upCh = upDev->GetChannel();
          if (!upCh || upCh->GetNDevices() < 2) continue;

          Ptr<NetDevice> upPeer = (upCh->GetDevice(0) == upDev) ? upCh->GetDevice(1) : upCh->GetDevice(0);
          if (!upPeer) continue;

          for (uint32_t a = 0; a < aggrs.GetN(); ++a) {
            if (aggrs.Get(a) == upPeer->GetNode()) {
              edgeToAggrPort = dd;
              connectedAggr = upPeer->GetNode();

              // 用指针匹配在 Aggr 节点上找设备下标（不要用 IfIndex 当设备号）
              aggrToEdgePort = std::numeric_limits<uint32_t>::max();
              for (uint32_t ai = 0; ai < connectedAggr->GetNDevices(); ++ai) {
                if (connectedAggr->GetDevice(ai) == upPeer) {
                  aggrToEdgePort = ai;
                  break;
                }
              }
              break;
            }
          }
          if (connectedAggr) break;
        }
        break;
      }
    }
    if (sinkEdge && connectedAggr) break;
  }

  NS_ABORT_MSG_IF(!sinkEdge || !connectedAggr, "Cannot find edge-aggr link");
  NS_ABORT_MSG_IF(aggrToEdgePort == std::numeric_limits<uint32_t>::max(), "Aggr device index not found");

  g_monitorLink.aggrNodeId = connectedAggr->GetId();
  g_monitorLink.aggrDevId = aggrToEdgePort;
  g_monitorLink.edgeNodeId = sinkEdge->GetId();
  g_monitorLink.edgeDevId = edgeToAggrPort;
  g_monitorLink.edgeHostPortId = edgeToHostPort;
  g_monitorLink.sinkNodeId = sink->GetId();

  std::cout << "Monitored Link:" << std::endl;
  std::cout << "  Aggr: Node " << g_monitorLink.aggrNodeId
            << " Dev " << g_monitorLink.aggrDevId << std::endl;
  std::cout << "    |  (downlink)" << std::endl;
  std::cout << "    v" << std::endl;
  std::cout << "  Edge: Node " << g_monitorLink.edgeNodeId
            << " Dev " << g_monitorLink.edgeDevId << std::endl;
  std::cout << "  Edge->Host Dev " << g_monitorLink.edgeHostPortId
            << " (sink node " << g_monitorLink.sinkNodeId << ")" << std::endl;

  UintegerValue highVal, lowVal;
  Ptr<QbbNetDevice> edgeDev = DynamicCast<QbbNetDevice>(sinkEdge->GetDevice(edgeToAggrPort));
  edgeDev->GetAttribute("PfcHighPkts", highVal);
  edgeDev->GetAttribute("PfcLowPkts", lowVal);
  g_monitorLink.high = highVal.Get();
  g_monitorLink.low = lowVal.Get();

  std::cout << "PFC Thresholds: HIGH=" << g_monitorLink.high
            << " pkts, LOW=" << g_monitorLink.low << " pkts" << std::endl;
  std::cout << "Priority: " << unsigned(kWatchPrio) << std::endl;
  std::cout << "===================================\n" << std::endl;

  // 挂在 Edge 侧与 Aggr 相连的端口的 MacRx，打印“上线到达间隔”（真实链路节奏）
  Ptr<QbbNetDevice> edgeRxDev = DynamicCast<QbbNetDevice>(sinkEdge->GetDevice(edgeToAggrPort));
  if (edgeRxDev) {
    edgeRxDev->TraceConnectWithoutContext("MacRx", MakeCallback(&TraceOnWireAggrToEdgeRx));
  }

  // 发送端应用：除接收 pod 外，其他 pod 的全部主机
  std::vector<Ptr<Node>> senders;
  for (uint32_t pod = 0; pod < k; ++pod) {
    if (pod == sinkPod) continue;
    const uint32_t base = pod * hostsPerPod;
    for (uint32_t i = 0; i < hostsPerPod; ++i) {
      senders.push_back(hosts.Get(base + i));
    }
  }

  for (uint32_t i = 0; i < senders.size(); ++i) {
    PacketSinkHelper sinkHelper("ns3::UdpSocketFactory",
                                InetSocketAddress(Ipv4Address::GetAny(), basePort + i));
    auto apps = sinkHelper.Install(sink);
    apps.Start(Seconds(0.1));
    apps.Stop(Seconds(simTime - 0.01));
  }

  const Time start = Seconds(0.2);
  const uint32_t packetsPerSender = 5;

  for (uint32_t i = 0; i < senders.size(); ++i) {
    Ptr<Node> s = senders[i];
    Ipv4Address sIp = GetFirstNonLoopbackIp(s);

    Ptr<QbbNetDevice> sDev;
    for (uint32_t di = 0; di < s->GetNDevices(); ++di) {
      sDev = DynamicCast<QbbNetDevice>(s->GetDevice(di));
      if (sDev) break;
    }

    Ptr<Socket> sock = Socket::CreateSocket(s, UdpSocketFactory::GetTypeId());
    sock->Bind(InetSocketAddress(sIp, basePort + 300 + i));
    sock->SetIpTos(kWatchPrio << 5);
    sock->Connect(InetSocketAddress(sinkIp, basePort + i));

    DataRateValue dv; sDev->GetAttribute("DataRate", dv);
    const double br = dv.Get().GetBitRate();
    const uint32_t onWireBytes = pktSize + 20 + 8 + 2;
    const double intv = (onWireBytes * 8.0) / br;

    Simulator::Schedule(start, &SendFixedPackets, sock, pktSize, Seconds(intv),
                        packetsPerSender, 0);
  }

  // 启动状态监控
  Simulator::Schedule(start, &MonitorLinkStatus);

  // 在 EnsureTokenManager 可能已安装后，打印 Edge 节点令牌注册参数
  Simulator::Schedule(start + MilliSeconds(80), &PrintEdgeTokenRegistration);

  Simulator::Schedule(Seconds(simTime - 1e-3), &QbbNetDevice::PrintAllPfcCounters);
}

} // namespace traffic
