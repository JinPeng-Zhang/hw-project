#ifndef TRAFFIC_TEST_H
#define TRAFFIC_TEST_H

#include <cstdint>

namespace ns3 {
class FatTreeTopology;
}

/*
  安装两条并发 TCP 流：
  - 源IP相同（同一个源主机，位于 pod 0）
  - 目的IP相同（同一个目的主机，位于 pod k-1）
  - 源端口不同（basePort+1000 / basePort+2000）
  - 目的端口相同（basePort）
  - 程序会在仿真中打印两条流的首包实际转发路径
*/
namespace traffic {

void InstallPfcTestTraffic(ns3::FatTreeTopology& topo,
                           double simTime,
                           uint32_t fanIn,
                           double rateBps,
                           uint32_t pktSize,
                           uint16_t basePort);

} // namespace traffic

#endif // TRAFFIC_TEST_H
