#ifndef FATTREE_EXPERIMENTS_H
#define FATTREE_EXPERIMENTS_H

#include <string>
#include <cstdint>  // for uint32_t

namespace ns3 {
class FatTreeTopology;
}

namespace fattree {

// 仅 PFC + ECMP 的场景入口
void RunScenario(ns3::FatTreeTopology& topo,
                 double simTime,
                 const std::string& ecmpMode,
                 bool pfcOn,
                 uint32_t pfcHighPkts,
                 uint32_t pfcLowPkts,
                 uint32_t pfcFanIn,
                 double pfcRateBps,
                 uint32_t pfcPktSize);

} // namespace fattree

#endif // FATTREE_EXPERIMENTS_H
